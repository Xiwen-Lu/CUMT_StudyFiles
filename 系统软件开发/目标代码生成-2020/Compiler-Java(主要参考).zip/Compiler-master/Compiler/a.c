void main()
{
  int sum=0,a=5,b=4,c;
  for(int i=1;i<11;i++){
  sum=sum+i;
  for(int i=1;i<11;i++){
  a=(1+2)*3;
  }
  }
  if(a>b){
  c=0;
  if(a>c){
  c=0;
  }
  else {
  c=1;
  }
  }
  else {
  c=1;
  }
}
#
