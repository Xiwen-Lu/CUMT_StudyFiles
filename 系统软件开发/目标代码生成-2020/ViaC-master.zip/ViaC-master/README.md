# ViaC语言编译器
Viac语言compiler
主要面对ViaC语言，兼容C89语言大部分，目前不支持while、switch(可以用for替代)、include等，
支持指针、sizeof、for、int、double等语法。
新增do、end以及//(行注释符），并且新增了require(头文件)机制。

C89  编译器
c#5.0 编辑器

单文件编译演示
![file test](https://raw.githubusercontent.com/as981242002/ViaC/master/viac/viac/filetest.gif)

项目编译演示
![Project test](https://raw.githubusercontent.com/as981242002/ViaC/master/viac/viac/projecttest.gif)
