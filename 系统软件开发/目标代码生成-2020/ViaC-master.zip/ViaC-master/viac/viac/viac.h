/******************************************
*Author:Away
*Date:2016-10-25
*Function:ͨ�õ�ͷ�ļ�
*******************************************/

#ifndef ViaC_H_
#define ViaC_H_

#include<windows.h>
#include<stdio.h>
#include"array.h"
#include"string.h"
#include"compile.h"
#include"lex.h"
#include"error.h"
#include"stack.h"
#include"sym.h"
#include"coff.h"
#include"operand.h"
#include"grammar.h"
#include"gencode.h"
#include"outpe.h"


#endif // viac.h_




