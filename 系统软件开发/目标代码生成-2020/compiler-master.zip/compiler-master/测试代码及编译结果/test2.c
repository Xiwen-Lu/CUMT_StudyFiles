main()
{
	int a,b,c;
	int d;

	a = 0;
	b = a+1;
	c = 10-b;
	d = b*c;
	printf("a=%d  b=%d  c=%d  d=%d",a,b,c,d);

    d = c/3;
	printf("  d=%d",d);
}