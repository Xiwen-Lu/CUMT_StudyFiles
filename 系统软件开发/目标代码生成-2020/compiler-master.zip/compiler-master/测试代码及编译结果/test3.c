main()
{
	int a,b;
	
	a = 4;
	b = 2;
	if(a>b)
	{
		a = a+1;
	}
	
	if(b<1)
	{
		b = b-1;
	}
	else
	{
		b = b+1;
	}
	printf("a=%d b=%d",a,b);
}