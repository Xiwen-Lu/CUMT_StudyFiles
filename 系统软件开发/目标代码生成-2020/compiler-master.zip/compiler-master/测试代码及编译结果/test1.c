main( )
{
    char x, y, z;
    x = 5;
    y = 4;
    z = x + y;
    printf("z=%d", z);
}
