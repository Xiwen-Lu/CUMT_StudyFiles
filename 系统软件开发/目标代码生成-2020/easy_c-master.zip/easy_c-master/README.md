# easy_c
一个简易的 c-----------编译器

这是一个基于x86平台的简易的c----------------编译器，刚才的减号可不是分界线，为什么这么多减呢？  我减了很多语法 ~_^ 。

语法定义在： https://blog.csdn.net/fierygit/article/details/104102909

用法：

![image](https://raw.githubusercontent.com/Fierygit/picbed/master/20200128214503.png)


gcc 使用的是  GNU AS 的连接， 我直接使用gcc 的连接， 当作于使用 GNU AS 的链接。


example:

![](https://raw.githubusercontent.com/Fierygit/picbed/master/20200130193901.png)

![](https://raw.githubusercontent.com/Fierygit/picbed/master/1580218434(1).jpg)
