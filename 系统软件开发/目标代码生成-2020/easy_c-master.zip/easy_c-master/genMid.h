/*
 * @Author: Firefly
 * @Date: 2020-01-23 00:28:25
 * @Descripttion:
 * @LastEditTime : 2020-01-23 21:25:57
 */
#include "global.h"
#include "util.h"

void genMid();

void traverse(TreeNode *node, void (*preProc)(TreeNode *),
              void (*postProc)(TreeNode *));


void Gen_S(TreeNode *node);


