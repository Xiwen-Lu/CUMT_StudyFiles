/*
 * @Author: Firefly
 * @Date: 2020-01-26 23:05:34
 * @Descripttion: 
 * @LastEditTime : 2020-01-27 12:37:33
 */
#include "global.h"



void genAsm();

void genAsign(MidCodeItem* node, string funcName);